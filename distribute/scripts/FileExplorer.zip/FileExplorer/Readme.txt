-------- www.bracketcounters.com --------

First, execute ```pip install -r requirements.txt```
	On Linux: ```pip3 install -r requirements.txt```

NOTE: If you are using the Linux operating system (VPS), open 'fileExplorer.py' with any text editor (e.g., nano) and change the variable called 'operatingSystem' to 'linux'. Then, open the terminal and run ```sudo ufw allow 5000```; otherwise, you will not be able to access the file explorer with your browser.


Finally, open terminal and run ```python fileExplorer.py```
	On linux: ```python3 fileExplorer.py```

NOTE: If you are using the Linux operating system (VPS), run ```sudo ufw delete allow 5000``` after exploring the file explorer through this script.