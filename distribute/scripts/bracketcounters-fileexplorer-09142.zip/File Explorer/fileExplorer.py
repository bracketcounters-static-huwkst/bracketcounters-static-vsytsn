from flask import Flask, render_template_string, request, send_file, render_template
import os
import time
from base64 import b64decode
from platform import system

app = Flask(__name__)

operatingSystem = system().lower()

class FileExplorer:
    def __init__(self, path, operatingSystem):
        self.cwd = os.getcwd()
        self.rootDir = str(self.cwd).split("\\")[0] + "\\"
        if operatingSystem == "linux":
            self.rootDir = "/"
        self.path = path
    def getFolderData(self):
        folderToScan = self.rootDir + self.path
        if not os.path.exists(folderToScan):
            return None
        if os.path.isfile(folderToScan):
            return False
        try:
            itemList = os.scandir(folderToScan)
        except Exception as e:
            return None
        folderDataFD = []
        folderDataFL = []
        currentPath = self.path
        if currentPath != "/":
            currentPath = currentPath + "/"
        for item in itemList:
            if item.is_dir():
                data = {
                "name": item.name + "/",
                "path": currentPath + os.path.basename(item.path),
                "type": "dir",
                "size": "",
                "date_modified": time.strftime("%m/%d/%y, %I:%M:%S %p", time.strptime(time.ctime(os.path.getmtime(item.path))))
                }
                folderDataFD.append(data)
            else:
                data = {
                    "name": item.name,
                    "path": currentPath + os.path.basename(item.path),
                    "type": "file",
                    "size": self.convertSize(os.path.getsize(os.path.abspath(item.path))),
                    "date_modified": time.strftime("%m/%d/%y, %I:%M:%S %p", time.strptime(time.ctime(os.path.getmtime(item.path))))
                }
                folderDataFL.append(data)
        folderData = folderDataFD + folderDataFL
        return folderData

    def getFile(self):
        return send_file(self.rootDir + self.path)

    @staticmethod
    def convertSize(initialSize):
        units = ['B', 'kB', 'MB', 'GB', 'TB']
        unit = 'B'
        size = initialSize
        if initialSize <= 1024:
            unit = units[0]
        elif initialSize <= (1024*1024):
            unit = units[1]
            size = (initialSize/1024)
        elif initialSize <= (1024*1024*1024):
            unit = units[2]
            size = (initialSize/(1024*1024))
        elif initialSize <= (1024*1024*1024*1024):
            unit = units[3]
            size = (initialSize/(1024*1024*1024))
        elif initialSize <= (1024*1024*1024*1024*1024):
            unit = units[4]
            size = (initialSize/(1024*1024*1024*1024))
        return (str(round(size, 2)) + " " + unit)

def sendImage(encodedString):
    """This will decode the image and send it as response"""
    responseData = app.response_class(
        response=b64decode(encodedString),
        status=200,
        mimetype="image/png"
    )
    return responseData

pages = {
    "index": """<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        a {
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
        tbody tr {
            position: relative;
        }
        tbody tr::after {
            position: absolute;
            left: 0;
            top: -2px;
        }
        .dir::after {
            content: url(/~server/~/static/~/folder-icon.png);
        }
        .file::after {
            content: url(/~server/~/static/~/file-icon.png);
        }
        tbody tr td::first-letter {
            margin-left: 26px;
        }
        .parent {
            margin-bottom: 15px;
            display: block;
            position: relative;
        }
        .parent::after {
            content: url(/~server/~/static/~/parent-folder-icon.png);
            position: absolute;
            left: 0;
            top: -2px;
        }
        .parent::first-letter {
            margin-left: 26px;
        }
    </style>
    <title>Index of {{ currentFolder }}</title>
</head>
<body>
    <h1 style="border-bottom: solid 1px #bbb; padding-bottom: 10px;">Index of {{ currentFolder }}</h1>
    {% if parentFolderShow %}
    <a href="{{ parentFolder }}" class="parent">[parent directory]</a>
    {% endif %}
    <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Size</th>
                <th>Date Modified</th>
            </tr>
        </thead>
        <tbody>
            {% for data in folderData %}
            <tr class="{{ data['type'] }}">
                <td><a href="{{ data['path'] }}">{{ data['name'] }}</a></td>
                <td>{{ data['size'] }}</td>
                <td>{{ data['date_modified'] }}</td>
            </tr>
            {% endfor %}
        </tbody>
    </table>
</body>
</html>""",
    
    "error": """<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Error</title>
</head>
<body>
    <h1>Error</h1>
    <p>Sorry, this page does not exists or this folder/file is inaccessible.</p>
</body>
</html>"""
}

images = {
    "file-icon": "iVBORw0KGgoAAAANSUhEUgAAABUAAAAXCAYAAADk3wSdAAAACXBIWXMAAAETAAABEwGpfUaAAAAApElEQVQ4je2V0Q3CMAxE3yEGYARGYISOwAZ0BEZghG5AR+koHYENDgX5o0JNqGh+EL2fKMrpxXZkR7aprV114k9B99ONpCtwKPg724/FUEkNcAL6jLcFhvAsjxQYbQ9zxrj0Iqm33Zag39Q0gatDk+6SjrnD9/RL6qKmRF1TtLdV0Hj1F1RSWpqc9887aoNu0MqatukInGPEfVIa5LN9n1T/NwWe05chrKRGQnoAAAAASUVORK5CYII=",
    "folder-icon": "iVBORw0KGgoAAAANSUhEUgAAABEAAAAZCAYAAADXPsWXAAAACXBIWXMAAADsAAAA7AF5KHG9AAAAzElEQVQ4jWP8//8/A6WAiST9F1gEsAkjXHKBxQEqpgDFIA0GUDEQzQ9lLxS2/5v49iPCCxBDLrAsYGBgiCfWQXtO/D0lzM+w3TDyfwMDkneINgAETPwPmDEwMMBcTmKY4ACjhowaMnIMUTi/nNGAUkPkGRgYzoMMokbACgxc7Hx+cwGFzwKlLzIwMOgTa8jNowUnhfkZfjAwMHxgYGB4ACseQaEcgFS+goA9DjMuCtr+NXz/Gb2MxQcusKAX3BMYDP6AXAAHlNc7DAwMACsDPvULFgJcAAAAAElFTkSuQmCC",
    "parent-folder-icon": "iVBORw0KGgoAAAANSUhEUgAAABUAAAAcCAYAAACOGPReAAAACXBIWXMAAAGJAAABiQGeLhE1AAABbklEQVRIiWP8//8/A7UBE9VNpKuhttu9N9hu93Yg11AWLAaCDPPXYPrD8e8irwADA4MBVApEC0CxPlRs4sGH7UWOfjn/kM3AiCjb7d4LGBgY4kHs7RKnGLiYfuB00Y+f7I8u3JCS42D/F2gUfmUDTBzF+7bbvQVgBoLAzi8qeL3JyqHNL62ZxIDkG0xDGRgYEpA5277z4TUUF0A3tACZc+svC8P570rkGwqNIHl0Bfu/CVHk0gJsCjb+5GJ4+4c0g9G9H8jAwHAQxmkTeM4QzfmZ4c1fLpIMhafTw55bAxggwQB3sQjzd4Y0wdskGYjNpVQBo4ZSBTicW6kDz6oYpRQDA8MFJ7Yf9iAGF+NvYi0EqT8ALcEwDT3subXg30XefDKczw9jDL7Y//fn/Y/Pr87BuB9hDGxhCgILkctVXICZ8eGD31+YIhkYGEAl/QOYMoJV9L+LvMjVCCyGYfXXBCb9zxvQ9YzW+1QGDAwMAJRKZDEnfVVJAAAAAElFTkSuQmCC"
}

@app.errorhandler(404)
def index(error):
    fl = FileExplorer(request.path, operatingSystem)
    folderData = fl.getFolderData()
    rootDir = fl.rootDir
    if folderData == None:
        return render_template_string(pages["error"])
    elif folderData == False:
        return fl.getFile()
    path = request.path.replace("/", "\\")
    if path == "\\":
        path = ""
    else:
        path = path + "\\"
        rootDir = rootDir.replace("\\", "")
    currentFolder = rootDir + path
    tempFolderSplited = fl.path.split("/")
    while("" in tempFolderSplited):
        tempFolderSplited.remove("")
    if len(tempFolderSplited) > 0:
        tempFolderSplited.pop()

    parentFolder = ""
    for f in tempFolderSplited:
        parentFolder += "/" + f
    if parentFolder == "":
        parentFolder = "/"

    parentFolderShow = True
    if request.path == "/":
        parentFolderShow = False

    if request.path != "/" and operatingSystem == "linux":
        currentFolder = path

    if operatingSystem == "linux":
        currentFolder = currentFolder.replace("\\", "/")

    return render_template_string(pages['index'], folderData=folderData, currentFolder=currentFolder, parentFolder=parentFolder, parentFolderShow=parentFolderShow)

@app.route("/~server/~/static/~/folder-icon.png")
def folder_icon():
    return sendImage(images["folder-icon"])

@app.route("/~server/~/static/~/file-icon.png")
def file_icon():
    return sendImage(images["file-icon"])

@app.route("/~server/~/static/~/parent-folder-icon.png")
def parent_folder_icon():
    return sendImage(images["parent-folder-icon"])

if __name__ == "__main__":
    app.run(debug=False, host="0.0.0.0")

