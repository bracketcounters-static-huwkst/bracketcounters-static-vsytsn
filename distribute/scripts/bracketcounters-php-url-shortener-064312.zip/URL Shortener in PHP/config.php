<?php
/**
 * @author    BracketCounters.com
 * @url       https://www.bracketcounters.com/
 */

// You have to set these manually
$dbhost = "localhost";
$username = "root";
$password = "";
$database = "shortener";
$connection = mysqli_connect($dbhost, $username, $password, $database);

$rootPath = "/shortener";
$server = "http://localhost" . $rootPath;

function getHeader() {
    global $rootPath;
    echo '<nav class="navbar navbar-expand-lg navbar-dark bg-info">
    <div class="container-fluid">
      <a class="navbar-brand" href="' . $rootPath . '">URL Shortener</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="' . $rootPath . '">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="' . $rootPath . '/links.php">Links</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>';
}

function parseText($string) {
    $parsedString = str_replace(["'", "\\"], ["&apos;", "&bsol;"], $string);
    return $parsedString;
}


?>