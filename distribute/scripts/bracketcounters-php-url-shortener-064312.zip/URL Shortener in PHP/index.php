<?php
require_once "config.php";

function randomString() {
    $str = "_01234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $randomNumber = rand(6, 10);
    $randomString = substr(str_shuffle($str), 0, $randomNumber);
    return $randomString;
}

$showExistsError = false;
$showShortened = false;
if (isset($_POST['url'])) {
    $longURL = parseText($_POST['url']);
    // If alias is set then it will be taken, otherwise a random string will be generated and used as alias.
    if (isset($_POST['alias']) && !empty($_POST['alias'])) {
        $alias = parseText($_POST['alias']);
    }
    else {
        $alias = randomString();
    }

    // Check if the alias exists
    $sqlCheck = "SELECT `serial_number` FROM `urls` WHERE `alias` = '$alias'";
    $query = mysqli_query($connection, $sqlCheck);
    if (mysqli_num_rows($query) == 0) {
        $sqlInsert = "INSERT INTO `urls` (`alias`, `original_url`, `click_count`, `timestamp`) VALUES ('$alias', '$longURL', '0', CURRENT_TIMESTAMP)";
        $result = mysqli_query($connection, $sqlInsert);
        // Show alert if the link has been shortened
        if ($result) {
            $showShortened = true;
        }
    }
    // Show error if the alias exists
    else {
        $showExistsError = true;
    }
}

?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>URL Shortener</title>
</head>

<body>
    <?php getHeader(); ?>
    <?php 
    if ($showExistsError) {
        echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong>Error!</strong> This alias already exists.
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>';
    }
    if ($showShortened) {
        echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success!</strong> Link shortened. Click here to visit: <a target="_blank" href="'. $server . "/" . $alias .'">'. $server . "/" . $alias .'</a>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>';
    }
    ?>
    <div class="container d-flex justify-content-center align-items-center" style="min-height: 90vh;">
        <div class="card" style="width: 100%;">
            <form class="card-body" method="POST">
                <h5 class="card-title">Shorten any URL</h5>
                <input type="url" name="url" class="form-control my-3" placeholder="Put your long link here" required>
                <div class="input-group my-3">
                    <span class="input-group-text" id="basic-addon3"><?php echo $server; ?>/</span>
                    <input type="text" class="form-control" name="alias" aria-describedby="basic-addon3" placeholder="Custom link alias..">
                </div>
                <button type="submit" class="btn btn-info text-light">Shorten</button>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>

</html>