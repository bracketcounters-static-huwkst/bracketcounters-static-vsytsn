<?php 
require_once "config.php";
$page = $_SERVER['REDIRECT_URL'];
$serverStrlen = strlen($rootPath);
$urlAlias = parseText(substr($page, $serverStrlen + 1));

$sqlFetch = "SELECT `original_url`, `click_count` FROM `urls` WHERE `alias` = '$urlAlias' LIMIT 1";
$query = mysqli_query($connection, $sqlFetch);

if (mysqli_num_rows($query) == 0) {
    require "error.php";
    http_response_code(404);
}
else {
    $row = mysqli_fetch_assoc($query);
    $originalLocation = $row['original_url'];
    $updatedClickCount = ((int) $row['click_count']) + 1;
    $sqlUpdateClick = "UPDATE `urls` SET `click_count` = '$updatedClickCount' WHERE `alias` = '$urlAlias'";
    mysqli_query($connection, $sqlUpdateClick);
    header("Location: $originalLocation");
    exit();
}

?>