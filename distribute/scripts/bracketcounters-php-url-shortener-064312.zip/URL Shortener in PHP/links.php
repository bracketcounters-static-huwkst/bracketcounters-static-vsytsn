<?php
require_once "config.php";

$sqlFetch = "SELECT * FROM `urls` ORDER BY `serial_number` DESC";
$query = mysqli_query($connection, $sqlFetch);

?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Your links</title>
</head>

<body>
    <?php getHeader(); ?>
    <div class="container my-3">
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Shortened URL</th>
                    <th scope="col">Original URL</th>
                    <th scope="col">Clicks</th>
                    <th scope="col">Timestamp</th>
                </tr>
            </thead>
            <tbody>
                <?php $i = 1; while ($row = mysqli_fetch_assoc($query)) { ?>
                <tr>
                    <th><?php echo $i; ?></th>
                    <td><a href="<?php echo $server . "/" . $row['alias'];  ?>" target="_blank"><?php echo $server . "/" . $row['alias'];  ?></a></td>
                    <td><?php echo $row['original_url']; ?></td>
                    <td><?php echo $row['click_count']; ?></td>
                    <td><?php echo $row['timestamp']; ?></td>
                </tr>
                <?php $i++; } ?>
            </tbody>
        </table>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>

</html>