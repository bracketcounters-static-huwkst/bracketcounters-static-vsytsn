---- www.bracketcounters.com ----

With password generator you can generate new, secure passwords. A random password will be generated every time.
The more attempts selected, the longer the password will be generated. 
In the 'Insert Words' section, you can insert the words of your choice that will be used to generate passwords later.
For example we have pre-inserted some words to generate your passwords initially.

Note: Please do not modify any files in the 'files' folder, or the application will not work properly.

